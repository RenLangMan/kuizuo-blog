import React from 'react';
import clsx from 'clsx';
import Link from '@docusaurus/Link';
import { PageMetadata } from '@docusaurus/theme-common';
import Layout from '@theme/Layout';
import WebsiteCard from './_components/WebsiteCard';
import BackToTopButton from '@theme/BackToTopButton';
import { websiteData } from '@site/data/website';
import styles from './website.module.css';

import Comment from '@site/src/components/Comment';
import style from '@site/src/pages/website/website.module.scss';

function CategoryNav() {
  const sidebar = {
    title: '',
    items: websiteData.map((w) => ({ title: w.name, permalink: `#${w.name}` })),
  };

  return (
    <nav className={clsx(styles.sidebar, 'thin-scrollbar')}>
      <div className={clsx(styles.sidebarItemTitle, 'margin-bottom--md')}>
        {sidebar.title}
      </div>
      <ul className={clsx(styles.sidebarItemList, 'clean-list')}>
        {sidebar.items.map((item) => (
          <li key={item.permalink} className={styles.sidebarItem}>
            <Link
              isNavLink
              to={item.permalink}
              className={styles.sidebarItemLink}
              activeClassName={styles.sidebarItemLinkActive}
            >
              {item.title}
            </Link>
          </li>
        ))}
      </ul>
    </nav>
  );
}

function CategoryList() {
  return (
    <div className={styles.category}>
      {websiteData.map((cate) => (
        <div key={cate.name}>
          <div className={styles.cateHeader}>
            <h2 id={cate.name} className="anchor">
              {cate.name}
              <a
                className="hash-link"
                href={`#${cate.name}`}
                title={cate.name}
              ></a>
            </h2>
          </div>
          <section>
            <ul className={styles.websiteList}>
              {cate.websites.map((website) => (
                <WebsiteCard key={website.name} website={website} />
              ))}
            </ul>
          </section>
        </div>
      ))}
      {/* <Comment /> */}
    </div>
  );
}

export default function Websites() {
  const title = '网址导航';
  const description = '整合日常开发常用，推荐的网站导航页';

  return (
    <>
      <PageMetadata title={title} description={description} />
      <Layout>
        <div className="container margin-top--md">
          <div className="row">
            <aside className="col col--1">
              <CategoryNav />
            </aside>
            <main className="col col--11">
              {/* <div className={style.typingslider}>
                <p>Here's my favorites.</p>
                <p>Feel free to browse through them.</p>
              </div> */}
              <CategoryList />
              <BackToTopButton />
            </main>
          </div>
        </div>
      </Layout>
    </>
  );
}
