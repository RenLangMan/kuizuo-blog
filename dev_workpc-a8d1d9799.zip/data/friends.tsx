// 友链信息
export const Friends: Friend[] = [
  {
    title: '愧怍',
    description: '魔改docusaurus大佬',
    website: 'https://kuizuo.cn/',
    avatar: '/img/friend/kui-zuo-logo.webp',
  },  
  {
    title: 'Ruyu-快乐猫',
    description: '全网最美开源博客ruyu-blog作者',
    website: 'https://www.kuailemao.xyz/',
    avatar: '/img/friend/ruyu-blog-logo.jpg',
  },  
  // {
  //   title: 'Simon He',
  //   description: 'Front-end development, Open source',
  //   website: 'https://simonme.netlify.app',
  //   avatar: '/img/friend/simonme.png',
  // },
  // {
  //   title: 'SkyWT',
  //   description: '热爱与激情永不止息。',
  //   website: 'https://skywt.cn',
  //   avatar: '/img/friend/skywt.png',
  // },
  // {
  //   title: 'Licodeao',
  //   description: 'The water flows incessantly, without vying for precedence.',
  //   website: 'https://www.licodeao.top',
  //   avatar: '/img/friend/licodeao.png',
  // },
  // {
  //   title: '云小逸',
  //   description: '不积跬步，无以至千里',
  //   website: 'https://www.gerenbiji.com',
  //   avatar: 'https://www.gerenbiji.com/img/logo.jpg',
  // },
  // {
  //   title: 'CWorld Blog',
  //   description: '求知若愚，虚怀若谷',
  //   website: 'https://cworld.top',
  //   avatar: '/img/friend/cworld.png',
  // },
  // {
  //   title: '尚宇',
  //   description: '心怀理想，仰望星空，埋头苦干',
  //   website: 'https://www.disnox.top',
  //   avatar: '/img/friend/disnox.png',
  // },
  // {
  //   title: 'Meoo',
  //   description: '一杯茶，一根网线，一台电脑',
  //   website: 'https://cxorz.com',
  //   avatar: '/img/friend/meoo.png',
  // },
  // {
  //   title: 'Shake',
  //   description: '世界继续热闹，愿你不变模样，勇敢且自由😃',
  //   website: 'https://www.shaking.site',
  //   avatar: '/img/friend/shake.png',
  // },
  // {
  //   title: 'Alan',
  //   description: '此刻想举重若轻，之前必要负重前行',
  //   website: 'https://www.alanwang.site',
  //   avatar: '/img/friend/alan.png',
  // },
  // {
  //   title: '鲸落',
  //   description: '心中无女人，代码自然神',
  //   website: 'http://www.xiaojunnan.cn',
  //   avatar: '/img/friend/xiaojunnan.png',
  // },
  // {
  //   title: 'LineXic书屋',
  //   description: '念念不忘，必有回响',
  //   website: 'https://linexic.top',
  //   avatar: '/img/friend/linexic.png',
  // },
]

export type Friend = {
  title: string
  description: string
  website: string
  avatar?: string
}
