#!/bin/bash

cat > /d/docusaurus/docs/5、关于我/关于本站/2、网站监控.md << EOF
---
title: 2、网站监控
id: website_monitor
slug: /website_monitor
---
EOF

##打印docusaurus_wiki大小
docusaurus_wiki_size="$(du -sh /d/docusaurus/docs|awk '{print $1}')"
echo "docusaurus_wiki大小为：$docusaurus_wiki_size" >>  /d/docusaurus/docs/5、关于我/关于本站/2、网站监控.md

##打印md数量
mdSum=$(find /d/docusaurus/docs/ -name "*.md"|wc -l)
mdSumResult=", 共 $mdSum 篇md"
echo $mdSumResult >>  /d/docusaurus/docs/5、关于我/关于本站/2、网站监控.md
echo "" >>  /d/docusaurus/docs/5、关于我/关于本站/2、网站监控.md


##打印图床信息、每日访问次数
ssh root@47.100.215.163 "sh /root/shell/private_shell/monitor.sh" >> /d/docusaurus/docs/5、关于我/关于本站/2、网站监控.md

