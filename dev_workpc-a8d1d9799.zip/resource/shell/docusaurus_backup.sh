#!/bin/bash
echo "开始备份docusaurus配置数据……"

cd /d/BaiduSyncdisk/backup/博客配置核心数据/2、win10配置/docusaurus备份
mkdir `date +%F`-docusaurus备份
cd `date +%F`-docusaurus备份

cp -a /d/docusaurus/README.md ./
cp -a /d/docusaurus/babel.config.js ./
cp -a /d/docusaurus/blog/ ./
#cp -a build/ ./
cp -a /d/docusaurus/custom.js ./
cp -a /d/docusaurus/docs/ ./
cp -a /d/docusaurus/docusaurus.config.js ./
#cp -a node_modules/ ./
cp -a /d/docusaurus/package-lock.json ./
cp -a /d/docusaurus/package.json ./
cp -a /d/docusaurus/resource/ ./
cp -a /d/docusaurus/rsync.exe.stackdump ./
cp -a /d/docusaurus/sidebars.js ./
cp -a /d/docusaurus/src/ ./
cp -a /d/docusaurus/static/ ./
cp -a /d/docusaurus/.gitignore ./
cp -a /d/docusaurus/.vscode ./

echo "docusaurus本地配置数据大小："
#会被强制覆盖掉当天的代码
du -sh /d/BaiduSyncdisk/backup/博客配置核心数据/2、win10配置/docusaurus备份/`date +%F`-docusaurus备份





echo "hexo backup-----------------------------------------"
echo "开始全量备份hexo配置数据……"

cd /d/BaiduSyncdisk/backup/博客配置核心数据/2、win10配置/hexo备份
mkdir `date +%F`-hexo备份
cd `date +%F`-hexo备份

#cp -a .git/
#cp -a .github/
cp -a /d/hexo/.gitignore ./
cp -a /d/hexo/README.md ./
cp -a /d/hexo/_config.landscape.yml ./
cp -a /d/hexo/_config.yml ./
cp -a /d/hexo/db.json ./
cp -a /d/hexo/md_source/ ./
#cp -a node_modules/
cp -a /d/hexo/package-lock.json ./
cp -a /d/hexo/package.json ./
#cp -a public/
cp -a /d/hexo/resource/ ./
cp -a /d/hexo/scaffolds/ ./
cp -a /d/hexo/themes/ ./



echo "hexo本地配置数据大小："
#会被强制覆盖掉当天的代码
du -sh /d/BaiduSyncdisk/backup/博客配置核心数据/2、win10配置/hexo备份/`date +%F`-hexo备份