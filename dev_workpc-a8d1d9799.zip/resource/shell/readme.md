## docusaurus.bat

推送winodws docusaurus static data to ecs...（rsync：winodws-->linux）

docusaurus构建后的静态数据：`build目录`

## latestUpdateArcticleTop10.sh

最近更新的10个md文件统计脚本。

## MdImages-rsync-linux-To-winodws.bat

nginx图床备份到本地的bat脚本，rsync服务（linux-->winodws）

## password.txt

rsync服务要用到的密码文件：存放ecs的登录密码。

## wiki.sh

git的相关命令。

## xyy2.sh

推送静态数据到ecs脚本。