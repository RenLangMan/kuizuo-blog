#!/bin/bash


# for i in {1..10}
# do
#   echo "Iteration $i"
# done

# 将脚本赋值给变量
script=$(cat <<'END_SCRIPT'
for i in {1..10}
do
  find /d/docusaurus/docs/ -name "*.md" ! -name 'latestUpdateArcticleTop10.md' -type f -exec stat --format="%y %n" {} + | sort -n -r | head -${i}|tail -1|awk '{print $1"---"$4}';echo -e
done
END_SCRIPT
)

cat > /d/docusaurus/docs/5、关于我/关于本站/3、latestUpdateArcticleTop10.md << EOF
---
title: 3、最近更新
id: latestUpdateArcticleTop10
slug: /latestUpdateArcticleTop10
---
EOF


# 执行脚本
eval "$script" >> /d/docusaurus/docs/5、关于我/关于本站/3、latestUpdateArcticleTop10.md

